function [sessionSummary] = get_tuning(sessionSummary) 
% function [behav, tuning, traj_quant, CJ_traj_easysplit, CV_traj_chX] = get_tuning(sessionSummary) %#ok<STOUT>
%
% does all the preliminary analyses on the sessionSummary, so we dont have
% to save the full trajectories
%

% 
% author: camillo, september 2014
% 


%atleast_nntrials = 2;
Tstimon_ms	= sessionSummary.params.simul.Tstimon_ms;
Tstimdur_ms	= sessionSummary.params.simul.Tstimdur_ms; %#ok<*NASGU>
Ttotal_ms	= sessionSummary.params.simul.Ttotal_ms;
binsize_ms	= sessionSummary.params.simul.binsize_ms;
%
rangeA		= sessionSummary.params.behav.rangeA;
rangeB		= sessionSummary.params.behav.rangeB;
%
offerList	= sessionSummary.behavData.offerList;
offA		= offerList(:,2);
offB		= offerList(:,3);
%
rOV1_traj	= sessionSummary.trajectory.rOV1_traj;
rOV2_traj	= sessionSummary.trajectory.rOV2_traj;
r1_traj		= sessionSummary.trajectory.r1_traj;
r2_traj		= sessionSummary.trajectory.r2_traj;
r3_traj		= sessionSummary.trajectory.r3_traj;
rI_traj		= sessionSummary.trajectory.rI_traj;

%define time windows
choicebins	= round((Tstimon_ms+[400 600])/binsize_ms);		%twin for decision & final	-- JNP submission
timewindow_OV_ms = Tstimon_ms + [0,500];					%twin for OV tuning curves	-- JNP submission
timewindow_CJ_ms = Tstimon_ms + [500,1000];					%twin for CJ tuning curves	-- JNP submission
timewindow_CV_ms = Tstimon_ms + [0,500];					%twin for CV tuning curves	-- JNP submission
timewindow_NS_ms = Tstimon_ms + [0,500];					%twin for NS tuning curves

% %test to check whether the twin defined for decision makes a difference
% choicebins	= round((Tstimon_ms+[200 500])/binsize_ms);	%twin for decision & final
% timewindow_OV_ms = Tstimon_ms + [0,500];					%twin for OV tuning curves
% timewindow_CJ_ms = Tstimon_ms + [0,500];					%twin for CJ tuning curves
% timewindow_CV_ms = Tstimon_ms + [0,500];					%twin for CV tuning curves


%extract choices from CJ cells
nbins = size(r1_traj, 2);
ind = zeros(1,nbins);
for i = choicebins(1):choicebins(2)
	ind(i) = 1;
end
ind = logical(ind);
%final activity for the 3 groups of cells
Afinal	= mean(r1_traj(:,ind),2);
Bfinal	= mean(r2_traj(:,ind),2);
Ach		= Afinal>Bfinal;				%A chosen
Bch		= Afinal<Bfinal;				%B chosen
%mark nan if Afinal = Bfinal
ii = ~Ach & ~Bch;
if sum(ii), disp('need to fix something here'), end

offerList = [offerList, Ach];

%remove error trials (forced choice trials in which the model selected 0)
ii = (~offA & Ach) | (~offB & Bch);
ii = ~ii;	%0 for error trials
%
offA = offA(ii,:);
offB = offB(ii,:);
Ach = Ach(ii,:);
Bch = Bch(ii,:); 
offerList	= offerList(ii,:);	sessionSummary.behavData.offerList	= offerList; 
rOV1_traj	= rOV1_traj(ii,:);	sessionSummary.trajectory.rOV1_traj = rOV1_traj;
rOV2_traj	= rOV2_traj(ii,:);	sessionSummary.trajectory.rOV2_traj	= rOV2_traj;
r1_traj		= r1_traj(ii,:);	sessionSummary.trajectory.r1_traj	= r1_traj;
r2_traj		= r2_traj(ii,:);	sessionSummary.trajectory.r2_traj	= r2_traj;
r3_traj		= r3_traj(ii,:);	sessionSummary.trajectory.r3_traj	= r3_traj;
rI_traj		= rI_traj(ii,:);	sessionSummary.trajectory.rI_traj	= rI_traj;

%
%compute table01
offtypes = unique([offA offB],'rows');
eps = 0.001;		%sort offtypes
aux = offtypes + eps;
[~, jnd] = sort(aux(:,2)./aux(:,1));
offtypes = offtypes(jnd,:);
%
nofftypes		= size(offtypes,1);
ntrials_offtype = nan(nofftypes,1);
perc_Bch		= nan(nofftypes,1);
for i = 1:nofftypes
	ind = ismember([offA offB],offtypes(i,:),'rows');
	ntrials_offtype(i) = sum(ind);
	perc_Bch(i) = sum(ind&Bch)/sum(ind);
end
if ~isequal(sum(ntrials_offtype),size(offA,1)), dummy, end
table01 = [offtypes, perc_Bch, ntrials_offtype];

%
%compute relvalue from choices
table1mod = table01(logical(table01(:,1) & table01(:,2)),:);
xx = table1mod(:,2)./table1mod(:,1);
xx = log(xx);	%log space
yy = table1mod(:,3);
%
g = fittype('normcdf(x,x0,w)','coeff',{'x0','w'});
[fittedmodel,goodness] = fit(xx, yy, g, ...
	'startpoint',[0 1], 'lower',[-Inf 0], 'upper',[Inf Inf]);
coefit = [fittedmodel.x0, fittedmodel.w];
%find the end of integration domain, imposing value distr. < epsilon
epsilon = 0.0001;	% for integration domain (how small the distr. before we ignore)
dx = .005;			% for Riemann's integral
leftlim = min(xx);
while normpdf(leftlim,coefit(1),coefit(2))>epsilon,		leftlim = leftlim-dx;	end
rightlim = max(xx);
while normpdf(rightlim,coefit(1),coefit(2))>epsilon,	rightlim = rightlim+dx;	end
%compute relvalue
relvalue = exp(fittedmodel.x0);
width = exp(fittedmodel.w);

%chosen value
chval	= relvalue*offA.*double(Ach) + offB.*double(Bch);


%behav output
tuning.table01 = table01;
behav.table01 = table01;
behav.relvalue = relvalue;
behav.width = width;


%compute tuning curves
%
%OV cells
timewindow_ms = timewindow_OV_ms;
tuning.rOV1 = tuning_W11(rOV1_traj, offerList, table01, timewindow_ms, binsize_ms);
tuning.rOV2 = tuning_W11(rOV2_traj, offerList, table01, timewindow_ms, binsize_ms);
%
%CJ cells
timewindow_ms = timewindow_CJ_ms;
tuning.r1 = tuning_W11(r1_traj, offerList, table01, timewindow_ms, binsize_ms);
tuning.r2 = tuning_W11(r2_traj, offerList, table01, timewindow_ms, binsize_ms);
%
%CV cells
timewindow_ms = timewindow_CV_ms;
tuning.rI = tuning_W11(rI_traj, offerList, table01, timewindow_ms, binsize_ms);
%
%NS cells
timewindow_ms = timewindow_NS_ms;
tuning.r3 = tuning_W11(r3_traj, offerList, table01, timewindow_ms, binsize_ms);


%
%compute average quantile trajectories
nbins = size(r1_traj, 2);
binTimes = (1:nbins)*binsize_ms;	%times for profile plots
binTimes = binTimes - Tstimon_ms;	%t=0 corresponds to offer on
%
%offval A
nquant = 3;
eval(['[n,binctr] = hist(offA,',num2str(nquant),');'])
delta = binctr(2) - binctr(1);
binedg = [-inf, binctr+delta/2]; binedg(end) = inf;
traj_quant.rOV1 = nan(nbins,nquant+1);
traj_quant.rOV1(:,1) = binTimes;
for iquant = 1:nquant
	ind = offA>=binedg(iquant) & offA<binedg(iquant+1);
	traj_quant.rOV1(:,iquant+1) = mean(rOV1_traj(ind,:))';
end
%offval B
nquant = 3;
eval(['[n,binctr] = hist(offB,',num2str(nquant),');'])
delta = binctr(2) - binctr(1);
binedg = [-inf, binctr+delta/2]; binedg(end) = inf;
traj_quant.rOV2 = nan(nbins,nquant+1);
traj_quant.rOV2(:,1) = binTimes;
for iquant = 1:nquant
	ind = offB>=binedg(iquant) & offB<binedg(iquant+1);
	traj_quant.rOV2(:,iquant+1) = mean(rOV2_traj(ind,:))';
end
%chjuice A
traj_quant.r1 = nan(nbins,3);
traj_quant.r1(:,1) = binTimes;
traj_quant.r1(:,2) = mean(r1_traj(Ach,:))';
traj_quant.r1(:,3) = mean(r1_traj(Bch,:))';
%chjuice B
traj_quant.r2 = nan(nbins,3);
traj_quant.r2(:,1) = binTimes;
traj_quant.r2(:,2) = mean(r2_traj(Ach,:))';
traj_quant.r2(:,3) = mean(r2_traj(Bch,:))';
%chval and ns cells
nquant = 3;
eval(['[n,binctr] = hist(chval,',num2str(nquant),');'])
delta = binctr(2) - binctr(1);
binedg = [-inf, binctr+delta/2]; binedg(end) = inf;
traj_quant.rI = nan(nbins,nquant+1);
traj_quant.rI(:,1) = binTimes;
traj_quant.r3 = nan(nbins,nquant+1);					%ns
traj_quant.r3(:,1) = binTimes;							%ns
for iquant = 1:nquant
	ind = chval>=binedg(iquant) & chval<binedg(iquant+1);
	traj_quant.rI(:,iquant+1) = mean(rI_traj(ind,:))';
	traj_quant.r3(:,iquant+1) = mean(r3_traj(ind,:))';	%ns
end


% for CJ cells, compute CJ_traj_easysplit
%
%identify split offtypes -- we work on tuning.bytrial
neuract = tuning.r1.bytrialtype;
iiA = neuract(:,3)==1;
iiB = neuract(:,3)==-1;
offtypes = intersect(neuract(iiA,1:2),neuract(iiB,1:2),'rows');
%
%identify trials from split offtypes -- we work on tuning.bytrial
neuract = tuning.r1.bytrial;
[~, ii] = sort(neuract(:,1));
neuract = neuract(ii,:);
iiA = neuract(:,4)==1;
iiB = neuract(:,4)==-1;
jj = ismember(neuract(:,2:3),offtypes,'rows'); %indices of trials from split offtypes
iiA_easy	= iiA & ~jj;	%these are trial indices (not trial numbers because we removed errors)
iiA_split	= iiA & jj;
iiB_easy	= iiB & ~jj;
iiB_split	= iiB & jj;
%compute easy and split trajectories, averaging r1 and r2
rE_traj_easy	= [r1_traj(iiA_easy,:); r2_traj(iiB_easy,:)];
rE_traj_split	= [r1_traj(iiA_split,:); r2_traj(iiB_split,:)];
rO_traj_split	= [r1_traj(iiB_split,:); r2_traj(iiA_split,:)];
rO_traj_easy	= [r1_traj(iiB_easy,:); r2_traj(iiA_easy,:)];
%
CJ_traj_easysplit.Eeasy		= [binTimes; mean(rE_traj_easy)]';
CJ_traj_easysplit.Esplit	= [binTimes; mean(rE_traj_split)]';
CJ_traj_easysplit.Osplit	= [binTimes; mean(rO_traj_split)]';
CJ_traj_easysplit.Oeasy		= [binTimes; mean(rO_traj_easy)]';


% now we examine the overshooting in CV cells (interneurons)
% 
% for each juice X and each quantity offX, we examine trials in which X is 
% chosen and devide offertypes in easy and split. then we average the
% activity across trials separately for easy and split trials. chosen value
% is the same for the two groups (offX is constant) but the alternative
% changes (higher alternative value for split trials)

XX = {'A','B'};
signXX = [1 -1];
for iX = 1:2
	X = XX{iX};
	signX = signXX(iX);
	eval(['CV_traj_chX.ch',X,'.binTimes	= binTimes;'])
	nn = 0;
	eval(['rangeX = sessionSummary.params.behav.range',X,';'])
	for offX = rangeX(1):rangeX(2)		%offX is the quantity of X offered
		%identify offtypes in which X is offered in quantity offX and decisions are easy, split
		neuract = tuning.rI.bytrialtype;
		iiX = neuract(:,iX)==offX & neuract(:,3)==signX;
		iiY = neuract(:,iX)==offX & neuract(:,3)==-signX;
		if ~sum(iiX) || ~sum(iiY), continue, end
		offtypes_easy	= setdiff(neuract(iiX,1:2),neuract(iiY,1:2),'rows');
		offtypes_split	= intersect(neuract(iiX,1:2),neuract(iiY,1:2),'rows');
		if isempty(offtypes_easy) || isempty(offtypes_split), continue, end
		nn = nn+1;
		%
		%identify trials from split offtypes -- we work on tuning.bytrial
		neuract = tuning.rI.bytrial;
		[~, ii] = sort(neuract(:,1));
		neuract = neuract(ii,:);
		jj_easy = ismember(neuract(:,2:3),offtypes_easy,'rows');	%indices of trials from easy offtypes
		jj_split = ismember(neuract(:,2:3),offtypes_split,'rows');	%indices of trials from split offtypes
		iiX = neuract(:,4)==signX;
		iiX_easy	= iiX & jj_easy;	%these are trial indices
		iiX_split	= iiX & jj_split;
		%
		%compute easy and split trajectories, averaging r1 and r2
		rI_traj = sessionSummary.trajectory.rI_traj;
		eval(['CV_traj_chX.ch',X,'.offX(:,nn)	= offX;'])
		eval(['CV_traj_chX.ch',X,'.easy(nn,:)	= mean(rI_traj(iiX_easy,:),1);'])
		eval(['CV_traj_chX.ch',X,'.split(nn,:)	= mean(rI_traj(iiX_split,:),1);'])
	end
end

% % to address qst from Rev2, we will compare the goodness of fit of CV cells onto chval vs totval
% %for each trial type we save the trajectory of CV cells
% atleast_nntrials = 2;
% neuract = tuning.rI.bytrialtype;
% trtypes = neuract(:,1:3);
% jj  = neuract(:,6)>= atleast_nntrials;
% trtypes = trtypes(jj,:);
% ntypes = size(trtypes,1);
% %
% neuract = tuning.rI.bytrial;
% [~, ii] = sort(neuract(:,1));
% neuract = neuract(ii,:);
% rI_traj = sessionSummary.trajectory.rI_traj;
% %
% act = nan(ntypes,nbins);
% for itype = 1:ntypes
% 	trtyp = trtypes(itype,:);
% 	ii = neuract(:,2)==trtyp(1) & neuract(:,3)==trtyp(2) & neuract(:,4)==trtyp(3);
% 	act(itype,:) = mean(rI_traj(ii,:));
% end
% CV_traj_bytrialtype.binTimes	= binTimes;
% CV_traj_bytrialtype.trialtypes	= trtypes;
% CV_traj_bytrialtype.act			= act;


%
% output
sessionSummary.behavData.table01		= behav.table01;
sessionSummary.behavData.relvalue		= behav.relvalue;
sessionSummary.behavData.width			= behav.width;
sessionSummary.tuning					= tuning;
sessionSummary.traj_quant				= traj_quant;
sessionSummary.CJ_traj_easysplit		= CJ_traj_easysplit;
sessionSummary.CV_traj_chX				= CV_traj_chX;
% sessionSummary.CV_traj_bytrialtype		= CV_traj_bytrialtype;

