function [] = plot_CJ_easysplit(filesuffix)
%
%

%#ok<*NODEF>
%#ok<*NASGU>

%clear all

%
% eval(['load simulations_results/sessionSumm_',filesuffix])
eval(['load sessionSumm_',filesuffix])

binTimes	= sessionSummary.CJ_traj_easysplit.Eeasy(:,1);
traj_Eeasy	= sessionSummary.CJ_traj_easysplit.Eeasy(:,2);
traj_Esplit = sessionSummary.CJ_traj_easysplit.Esplit(:,2);
traj_Osplit = sessionSummary.CJ_traj_easysplit.Osplit(:,2);
traj_Oeasy	= sessionSummary.CJ_traj_easysplit.Oeasy(:,2);

%lims for profile plots
xlim_profiles = [-500 1000];
fs = 9; lw = 2;
lw = 1.5;
clrs = [
	0 0 .75
	.6 .6 1
	1 .6 .6
	.8 0 0];

%
figure; set(gcf,'position',[650 700 470 430],'PaperPositionMode','auto'), hold on
plot(binTimes, traj_Eeasy,	'-', 'color',clrs(1,:), 'linewidth',lw)
plot(binTimes, traj_Esplit,	'-', 'color',clrs(2,:), 'linewidth',lw)
plot(binTimes, traj_Osplit,	'-', 'color',clrs(3,:), 'linewidth',lw)
plot(binTimes, traj_Oeasy,	'-', 'color',clrs(4,:), 'linewidth',lw)
% ylim = get(gca,'ylim'); plot([0 0],ylim,'k:')
set(gca,'xlim',xlim_profiles)

axes('position',[.17 .62 .27 .30]), hold on
xlim = [-300 100]; ylim = [3 4.5];
ii = find(binTimes==xlim(1)):find(binTimes==xlim(2));
plot(binTimes(ii), traj_Eeasy(ii),	'-', 'color',clrs(1,:), 'linewidth',lw)
plot(binTimes(ii), traj_Esplit(ii),	'-', 'color',clrs(2,:), 'linewidth',lw)
plot(binTimes(ii), traj_Osplit(ii),	'-', 'color',clrs(3,:), 'linewidth',lw)
plot(binTimes(ii), traj_Oeasy(ii),	'-', 'color',clrs(4,:), 'linewidth',lw)
% plot([0 0],ylim,'k:')
set(gca,'fontsize',7,'ytick',[3 4])
axis([xlim, ylim])
box on

title(filesuffix)

