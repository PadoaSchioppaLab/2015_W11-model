function [offList] = sessionParams(sessionmode)
%
% generates a list of offers for W11. this can be done explicitly or
% parametrically (as in the experiments)
%

%all explicit
if isequal(sessionmode,'explicit')
	ntrials = 2500;       % Total number of trials
	
	% value ranges in current session
	rangeA = [0 15];
	rangeB = [0 15];
	
	% offer ranks and quantities in each trial
	% NB: we do 2* to keep ntrials correct once we remove some trial types
	rankA = rand(2*ntrials, 1);	% rank of A, uniform in [0,1]
	rankB = rand(2*ntrials, 1);	% rank of B, uniform in [0,1]
	
	%offers
	offA = floor(rankA*(diff(rangeA)+1)) + rangeA(1);
	offB = floor(rankB*(diff(rangeB)+1)) + rangeB(1);
	
	%rm offers 0:0
	ii = offA==0 & offB==0;
% 	ii = ii | abs(offA - offB)<=2;		%rm difficult decisions
% 	ii = ii | min([offA,offB],[],2)>=2; %rm trials not included in exp
	offA = offA(~ii);
	offB = offB(~ii);
	offList	= [offA offB];
	offList = offList(1:ntrials,:);
	
elseif isequal(sessionmode,'parametric')
	
	nblocks = 15;
	offerTypes = [
		%N	#1	#2
		2	1	0
		2	5	1
		2	4	1
		2	3	1
		2	2	1
		2	1	1
		2	1	2
% 		2	1	3
		2	1	4
		2	1	6
		2	1	8
		2	1	10
		2	0	2];

	ntrials_block = sum(offerTypes(:,1));
	%
	offList = [];
	for iblock = 1:nblocks
		offerList_block = [];
		for itype = 1:size(offerTypes,1)
			for iiN = 1:offerTypes(itype,1)
				offerList_block = [offerList_block; offerTypes(itype,2:end)]; %#ok<AGROW>
			end
		end
		offerList_block = offerList_block(randperm(ntrials_block)',:);
		offList = [offList; offerList_block]; %#ok<AGROW>
	end
	
end