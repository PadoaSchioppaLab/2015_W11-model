% Wang's model with 11 variables, adapted for economic decisions and OFC activity
%

%
% original program:	KF Wong (Wong and Wang, 2006)
% modifications:	AR & CPS, 2013-2014
%


% Simplified model with 11 dynamical variables and 4 populations

clear all;

filesuffix = 'JNP2015';

%%%% Network parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%NE		= 1600;		% Total number of E-cells
CE		= 1600;		% Total number of connections / E-cell
Cext	= 800;		% Total number of external connections / cell
%CI		= 400;		% Total number of connections / I-cell
NI		= 400;		% Total number of I-cells
f		= 0.15;		% Fraction of structured (potentiated) synapses
nuext	= 3.0;		% Mean firing rates of external cells

%%%% Synaptic time constants %%%%%%%%%%%%%%%%%%%%%%%%%%%

Tnmda	= 100;		% Decay time constant of NMDA gating variables
Tampa	= 2;		% Decay time constant of AMPA gating variables
Tgaba	= 5;		% Decay time constant of GABA_A gating variables

%%%% Synaptic couplings. Basically (<V>-E)*g %%%%%%%%%%%%%%%%%%%%%%%%%%%

% External synapses
Jpampaext	= -0.1123;
Jiampaext	= -0.0842;

% synapses OV => 1,2
JpampaOV1	= 30*Jpampaext;		%cps
JpampaOV2	= 30*Jpampaext;

% Recurrent synapses
Jpampa		= -0.0027;
Jpnmdaeff	= -0.00091979;
Jpgaba		= 0.0215;			% To E-cells

Jiampa		= -0.0022;
Jinmdaeff	= -0.00083446;
Jigaba		= 0.0180;			% To I-cells

%%%% F-I curve parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Im = 125;	g = 0.16;	c = 310;	% Paramters for E-cell
ImI = 177;	gI = 0.087;	cI = 615;	% Parameters for I-cell


%%%% Parameters for Economic Choices %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[offList] = sessionParams('explicit');		%cover the plane
% [offList] = sessionParams('parametric');	%as in the experiments
offA	= offList(:,1);
offB	= offList(:,2);
rangeA	= [min(offA),max(offA)];
rangeB	= [min(offB),max(offB)];
ntrials = size(offList,1);


% %%% Clear variables for evaluations at end of (block) loop %%%%%%%%%%%%%%%%%%%
% 
% r1_traj=[]; r2_traj=[]; r3_traj=[]; rI_traj=[];
% s1_traj=[]; s2_traj=[]; s3_traj=[]; sI_traj=[];
% 
% %%% Parameters to be varied %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% coh = 0.0;					% Coherence level
% mu = 40;						% External stimulus strength
% w1 = 1.8;						% w+,Self-excitatory synaptic strenth
% w2 = 1-f*(w1-1)/(1-f);		% w-, Depressed synapses b/w E-cells to maintain equal spont. rate
% noise_amp = 0.008;			% For noise in current in all cells
% thresh = 15;					% Threshold in Hz


dj_OT		= [2 1];			% dj in connections OV => T to make relval~=1
dj_rev		= [1 1];			% dj in nmda reverberating connections
dj_inh		= [1 1];			% dj in connections inh => T
dj_HL = [rangeA(2)/rangeB(2) 1];% dj representing the endpoint of hebbian learning

w1			= 1.75;				% w+,Self-excitatory synaptic strenth		%cps -- was 1.8
w2			= 1-f*(w1-1)/(1-f);	% w-, Depressed synapses b/w E-cells to maintain equal spont. rate
noise_amp	= 0.020;			% For noise in current in all cells			%cps -- was 0.008
% thresh		= 15;			% Threshold in Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Trials number and (block) loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ww = 1:ntrials % Loop over trials
	if ~rem(ww,10), disp(['... processing trial number ',num2str(ww)]), end
	
	trial_no = ww;
	
% 	%---- Vectorise variables with sliding window -------------
% 	
% 	nu1_wind = [] ; nu2_wind = [] ; nu3_wind = [] ; nuI_wind = [] ;
% 	s1_wind = [] ; s2_wind = [] ;

% 	---- Initial conditions and clearing variables ------------
	
% 	if ww==1	%uncomment to implement choice hysteresis
	if 1		%comment out to implement choice hysteresis
		s1_in = 0.1; s2_in = 0.1; s3_in = 0.1;
		sampa1_in = 0; sampa2_in = 0; sampa3_in = 0;
		sgaba_in = 0;
		nu1_in = 3; nu2_in = 3; nu3_in = 3; nuI_in = 8;
	else
		%we implement hysteresis
		s1_in		= s1_traj(ww-1,end);	%#ok<UNRCH>
		s2_in		= s2_traj(ww-1,end);
		s3_in		= s3_traj(ww-1,end);
		sampa1_in	= sampa1_traj(ww-1,end);
		sampa2_in	= sampa2_traj(ww-1,end);
		sampa3_in	= sampa3_traj(ww-1,end);
		sgaba_in	= sgaba_traj(ww-1,end);
		nu1_in		= r1_traj(ww-1,end);
		nu2_in		= r2_traj(ww-1,end);
		nu3_in		= r3_traj(ww-1,end);
		nuI_in		= rI_traj(ww-1,end);
	end
	
	%------- Time conditions ---------------------------------------------------------------------
	
	dt			= 0.5;					% Time step in msec. Same for dt=0.25
	time_wind	= 50/dt;				% Temporal window size for averaging
	slide_wind	= 5/dt;					% Sliding step for window
	T_total		= 3000/dt + time_wind;	% Total number of steps
	T_stimon	= 1000/dt;				% Motion stimulus onset time
	T_stimdur	= 500/dt;				% Duration of motion viewing (delayed response tasks only)
	
	%----------- Intialise and vectorise variables to be used in loops below ---------------------
	
	s1 = s1_in.*ones(1,T_total);	sampa1 = sampa1_in.*ones(1,T_total);
	s2 = s2_in.*ones(1,T_total);	sampa2 = sampa2_in.*ones(1,T_total); 
	s3 = s3_in.*ones(1,T_total);	sampa3 = sampa3_in.*ones(1,T_total);
	sgaba = sgaba_in.*ones(1,T_total);	
	nu1 = nu1_in.*ones(1,T_total);	phi1 = nu1_in.*ones(1,T_total);
	nu2 = nu2_in.*ones(1,T_total);	phi2 = nu2_in.*ones(1,T_total);
	nu3 = nu3_in.*ones(1,T_total);	phi3 = nu3_in.*ones(1,T_total);
	nuI = nuI_in.*ones(1,T_total);	phiI = nuI_in.*ones(1,T_total);
	I_eta1 = zeros(1,T_total);	I_eta2 = zeros(1,T_total);	I_eta3 = zeros(1,T_total);	I_etaI = zeros(1,T_total);
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%% Time (or trial) loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%---- Offer value cells --------------------------------------------
	
	rankA = offA(ww)/rangeA(2);
	rankB = offB(ww)/rangeB(2);
	
% 	%boxcar input
% 	mu = 80;				% External stimulus strength (boxcar)
% 	nuOV1 = zeros(1,T_total);	nuOV1(T_stimon+1:T_stimon+T_stimdur-1) = mu*rankA;
% 	nuOV2 = zeros(1,T_total);	nuOV2(T_stimon+1:T_stimon+T_stimdur-1) = mu*rankB;
	
	%realistic input
	nuOV1 = get_nuOV(T_total,T_stimon,dt,rankA);
	nuOV2 = get_nuOV(T_total,T_stimon,dt,rankB);
	
	%time loop within the trial
	for t = 1:T_total
		
		%==== External current input =========================================================================
		
		IampaextE1 = -Jpampaext*Tampa*Cext*nuext/1000 + I_eta1(t);
		IampaextE2 = -Jpampaext*Tampa*Cext*nuext/1000 + I_eta2(t);
		IampaextE3 = -Jpampaext*Tampa*Cext*nuext/1000 + I_eta3(t);
		IampaextG = -Jiampaext*Tampa*Cext*nuext/1000 + I_etaI(t);
		
		%==== Experimental protocol (motion stimulus, offer values) ===========================================
		
% 		% For reaction time tasks
% 		%I_stim_1 = (T_stimon<t & t<T_total)*(-Jpampaext*Tampa*mu*(1+coh/100)/1000);
% 		%I_stim_2 = (T_stimon<t & t<T_total)*(-Jpampaext*Tampa*mu*(1-coh/100)/1000);
% 		
% 		% For delayed response tasks
% 		I_stim_1 = (T_stimon<t & t<T_stimon+T_stimdur)*(-Jpampaext*Tampa*mu*(1+coh/100)/1000);
% 		I_stim_2 = (T_stimon<t & t<T_stimon+T_stimdur)*(-Jpampaext*Tampa*mu*(1-coh/100)/1000);
% 		
% 		% offer values, without hebbian learning
% 		I_stim_1 = nuOV1(t)*dj_OT(1)*(-JpampaOV1*Tampa/1000);
% 		I_stim_2 = nuOV2(t)*dj_OT(2)*(-JpampaOV2*Tampa/1000);
		
		%offer values, with hebbian learning
		I_stim_1 = nuOV1(t)*dj_HL(1)*dj_OT(1)*(-JpampaOV1*Tampa/1000);
		I_stim_2 = nuOV2(t)*dj_HL(2)*dj_OT(2)*(-JpampaOV2*Tampa/1000);
		
		%==== Input to population 1 =========================================================================
		
		Iamparec1	= -CE*f*Jpampa*w1*sampa1(t) - CE*f*Jpampa*w2*sampa2(t) - CE*(1-2*f)*Jpampa*w2*sampa3(t);
% 		Inmda1		= -CE*f*Jpnmdaeff*w1*s1(t) - CE*f*Jpnmdaeff*w2*s2(t) - CE*(1-2*f)*Jpnmdaeff*w2*s3(t);
		Inmda1		= -CE*f*Jpnmdaeff*dj_rev(1)*w1*s1(t) - CE*f*Jpnmdaeff*w2*s2(t) - CE*(1-2*f)*Jpnmdaeff*w2*s3(t);
% 		Igaba1		= -NI*Jpgaba*sgaba(t);
		Igaba1		= -NI*Jpgaba*dj_inh(1)*sgaba(t);
		Isyn1		= Inmda1 + Iamparec1 + Igaba1 + IampaextE1 + I_stim_1;
		phi1(t)		= (c.*Isyn1-Im)./(1-exp(-g.*(c.*Isyn1-Im)));
		
		%==== Input to population 2 =========================================================================
		
		Iamparec2	= -CE*f*Jpampa*w1*sampa2(t) - CE*f*Jpampa*w2*sampa1(t) - CE*(1-2*f)*Jpampa*w2*sampa3(t);
% 		Inmda2		= -CE*f*Jpnmdaeff*w1*s2(t) - CE*f*Jpnmdaeff*w2*s1(t) - CE*(1-2*f)*Jpnmdaeff*w2*s3(t);
		Inmda2		= -CE*f*Jpnmdaeff*dj_rev(2)*w1*s2(t) - CE*f*Jpnmdaeff*w2*s1(t) - CE*(1-2*f)*Jpnmdaeff*w2*s3(t);
% 		Igaba2		= -NI*Jpgaba*sgaba(t);
		Igaba2		= -NI*Jpgaba*dj_inh(2)*sgaba(t);
		Isyn2		= Inmda2 + Iamparec2 + Igaba2 + IampaextE2 + I_stim_2;
		phi2(t)		= (c.*Isyn2-Im)./(1-exp(-g.*(c.*Isyn2-Im)));
		
		%==== Input to population 3 ==========================================================================
		
		Iamparec3	= -CE*(1-2*f)*Jpampa*sampa3(t) - CE*f*Jpampa*sampa1(t) - CE*f*Jpampa*sampa2(t);
		Inmda3		= -CE*(1-2*f)*Jpnmdaeff*s3(t) - CE*f*Jpnmdaeff*s1(t) - CE*f*Jpnmdaeff*s2(t);
		Igaba3		= -NI*Jpgaba*sgaba(t);
		Isyn3		= Inmda3 + Iamparec3 + Igaba3 + IampaextE3;
		phi3(t)		= (c.*Isyn3-Im)./(1-exp(-g.*(c.*Isyn3-Im)));
		
		%==== Input to population I ===========================================================================
		
		IamparecI	= -CE*(1-2*f)*Jiampa*sampa3(t) - CE*f*Jiampa*sampa1(t) - CE*f*Jiampa*sampa2(t);
		InmdaI		= -CE*(1-2*f)*Jinmdaeff*s3(t) - CE*f*Jinmdaeff*s1(t) - CE*f*Jinmdaeff*s2(t);
		IgabaI		= -NI*Jigaba*sgaba(t);
		IsynI		= InmdaI + IamparecI + IgabaI + IampaextG;
		phiI(t)		= (cI.*IsynI-ImI)./(1-exp(-gI.*(cI.*IsynI-ImI)));
		
		%==== Dynamical equations ===================================================
		
		% Average synaptic gating variables of NMDA
		s1(t+1)		= s1(t) + dt*(-(s1(t)/Tnmda) + (1-s1(t))*0.641*nu1(t)/1000);
		s2(t+1)		= s2(t) + dt*(-(s2(t)/Tnmda) + (1-s2(t))*0.641*nu2(t)/1000);
		s3(t+1)		= s3(t) + dt*(-(s3(t)/Tnmda) + (1-s3(t))*0.641*nu3(t)/1000);
		
		% Average synaptic gating variables of AMPA
		sampa1(t+1)	= sampa1(t) + dt*(-sampa1(t)/Tampa + nu1(t)/1000);
		sampa2(t+1)	= sampa2(t) + dt*(-sampa2(t)/Tampa + nu2(t)/1000);
		sampa3(t+1)	= sampa3(t) + dt*(-sampa3(t)/Tampa + nu3(t)/1000);
		
		% Average synaptic gating variables of GABA_A
		sgaba(t+1)	= sgaba(t) + dt*(-sgaba(t)/Tgaba + nuI(t)/1000);
		
		if phi1(t) > 500
			nu1(t+1) = 500;
			phi1(t) = 500;		% To prevent blowing up (high AMPA:NMDA); bound by 1/(refractory period of E cell)
		else
			nu1(t+1) = nu1(t) + (dt/Tampa)*(-nu1(t) + phi1(t));
		end;
		if phi2(t) > 500
			nu2(t+1) = 500;
			phi2(t) = 500;
		else
			nu2(t+1) = nu2(t) + (dt/Tampa)*(-nu2(t) + phi2(t));
		end;
		if phi3(t) > 500
			nu3(t+1) = 500;
			phi3(t) = 500;
		else
			nu3(t+1) = nu3(t) + (dt/Tampa)*(-nu3(t) + phi3(t));
		end;
		if phiI(t) > 1000
			nuI(t+1) = 1000;
			phiI(t) = 1000;		% To prevent blowing up (high AMPA:NMDA); bound by 1/(refractory period of I cell)
		else
			nuI(t+1) = nuI(t) + (dt/Tampa)*(-nuI(t) + phiI(t));
		end;
		
		% Generation of noise to each populations (filter with AMPA synaptic time constant)
		I_eta1(t+1) = I_eta1(t) + (dt/Tampa)*(-I_eta1(t)) + sqrt(dt/Tampa)*noise_amp*randn ;
		I_eta2(t+1) = I_eta2(t) + (dt/Tampa)*(-I_eta2(t)) + sqrt(dt/Tampa)*noise_amp*randn ;
		I_eta3(t+1) = I_eta3(t) + (dt/Tampa)*(-I_eta3(t)) + sqrt(dt/Tampa)*noise_amp*randn ;
		I_etaI(t+1) = I_etaI(t) + (dt/Tampa)*(-I_etaI(t)) + sqrt(dt/Tampa)*noise_amp*randn ;
		
	end; %---- End of time loop --------------
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	% To smooth the fluctuations of firing rates
	nwind = (T_total-time_wind)/slide_wind;
	nuOV1_wind	= nan(1,nwind);
	nuOV2_wind	= nan(1,nwind);
	nu1_wind	= nan(1,nwind);
	nu2_wind	= nan(1,nwind);
	nu3_wind	= nan(1,nwind);
	nuI_wind	= nan(1,nwind);
	s1_wind		= nan(1,nwind);
	s2_wind		= nan(1,nwind);
	s3_wind		= nan(1,nwind);
	sampa1_wind	=  nan(1,nwind);
	sampa2_wind	=  nan(1,nwind);
	sampa3_wind	=  nan(1,nwind);
	sgaba_wind	= nan(1,nwind);
	for jj = 1:nwind
		nuOV1_wind(jj)	= mean(nuOV1(jj*slide_wind:(jj*slide_wind+time_wind)));
		nuOV2_wind(jj)	= mean(nuOV2(jj*slide_wind:(jj*slide_wind+time_wind)));
		nu1_wind(jj)	= mean(nu1(jj*slide_wind:(jj*slide_wind+time_wind)));
		nu2_wind(jj)	= mean(nu2(jj*slide_wind:(jj*slide_wind+time_wind)));
		nu3_wind(jj)	= mean(nu3(jj*slide_wind:(jj*slide_wind+time_wind)));
		nuI_wind(jj)	= mean(nuI(jj*slide_wind:(jj*slide_wind+time_wind)));
		s1_wind(jj)		= mean(s1(jj*slide_wind:(jj*slide_wind+time_wind)));
		s2_wind(jj)		= mean(s2(jj*slide_wind:(jj*slide_wind+time_wind)));
		s3_wind(jj)		= mean(s3(jj*slide_wind:(jj*slide_wind+time_wind)));
		sampa1_wind(jj)	= mean(sampa1(jj*slide_wind:(jj*slide_wind+time_wind)));
		sampa2_wind(jj)	= mean(sampa2(jj*slide_wind:(jj*slide_wind+time_wind)));
		sampa3_wind(jj)	= mean(sampa3(jj*slide_wind:(jj*slide_wind+time_wind)));
		sgaba_wind(jj)	= mean(sgaba(jj*slide_wind:(jj*slide_wind+time_wind)));
	end
	nuOV1_wind	= [mean(nuOV1(1:time_wind)) nuOV1_wind];	%#ok<AGROW>
	nuOV2_wind	= [mean(nuOV2(1:time_wind)) nuOV2_wind];	%#ok<AGROW>
	nu1_wind	= [mean(nu1(1:time_wind)) nu1_wind];		%#ok<AGROW>
	nu2_wind	= [mean(nu2(1:time_wind)) nu2_wind];		%#ok<AGROW>
	nu3_wind	= [mean(nu3(1:time_wind)) nu3_wind];		%#ok<AGROW>
	nuI_wind	= [mean(nuI(1:time_wind)) nuI_wind];		%#ok<AGROW>
	s1_wind		= [mean(s1(1:time_wind)) s1_wind];			%#ok<AGROW>
	s2_wind		= [mean(s2(1:time_wind)) s2_wind];			%#ok<AGROW>
	s3_wind		= [mean(s3(1:time_wind)) s3_wind];			%#ok<AGROW>
	sampa1_wind	= [mean(sampa1(1:time_wind)) sampa1_wind];	%#ok<AGROW>
	sampa2_wind	= [mean(sampa2(1:time_wind)) sampa2_wind];	%#ok<AGROW>
	sampa3_wind	= [mean(sampa3(1:time_wind)) sampa3_wind];	%#ok<AGROW>
	sgaba_wind	= [mean(sgaba(1:time_wind)) sgaba_wind];	%#ok<AGROW>
	
	%initialize rj_traj
	if ww==1
		rOV1_traj	= nan(ntrials, nwind+1);
		rOV2_traj	= nan(ntrials, nwind+1);
		r1_traj		= nan(ntrials, nwind+1);
		r2_traj		= nan(ntrials, nwind+1);
		r3_traj		= nan(ntrials, nwind+1);
		rI_traj		= nan(ntrials, nwind+1);
		s1_traj		= nan(ntrials, nwind+1);
		s2_traj		= nan(ntrials, nwind+1);
		s3_traj		= nan(ntrials, nwind+1);
		sampa1_traj	= nan(ntrials, nwind+1);
		sampa2_traj	= nan(ntrials, nwind+1);
		sampa3_traj	= nan(ntrials, nwind+1);
		sgaba_traj	= nan(ntrials, nwind+1);
	end
	
	%save rj_traj
	rOV1_traj(ww,:)		= nuOV1_wind;
	rOV2_traj(ww,:)		= nuOV2_wind;
	r1_traj(ww,:)		= nu1_wind;
	r2_traj(ww,:)		= nu2_wind;
	r3_traj(ww,:)		= nu3_wind;
	rI_traj(ww,:)		= nuI_wind;
	s1_traj(ww,:)		= s1_wind;
	s2_traj(ww,:)		= s2_wind;
	s3_traj(ww,:)		= s3_wind;
	sampa1_traj(ww,:)	= sampa1_wind;
	sampa2_traj(ww,:)	= sampa2_wind;
	sampa3_traj(ww,:)	= sampa3_wind;
	sgaba_traj(ww,:)	= sgaba_wind;

	clear nuOV1 nuOV2 nuOV1_wind nuOV2_wind;
	clear nu1 nu2 nu3 nuI nu1_wind nu2_wind nu3_wind nuI_wind;
	clear s1 s2 s3 sgaba s1_wind s2_wind s3_wind sgaba_wind;
	clear sampa1 sampa2 sampa3 sampa1_wind sampa2_wind sampa3_wind;
	clear phi1 phi2 phi3 phiI I_eta1 I_eta2 I_eta3 I_etaI;

end; %---- End trial loop ---------


%#############################################################################################
%############### Session Summary #############################################################
%#############################################################################################

% save summary
sessionSummary.params.simul.Tstimon_ms	= T_stimon*dt;
sessionSummary.params.simul.Tstimdur_ms	= T_stimdur*dt;
sessionSummary.params.simul.Ttotal_ms	= T_total*dt;
sessionSummary.params.simul.binsize_ms	= slide_wind*dt;	%we'll call time chuncks "bin" instead of "wind"
%
sessionSummary.params.LIF.Im			= Im;		%E-cells
sessionSummary.params.LIF.g				= g;
sessionSummary.params.LIF.c				= c;
sessionSummary.params.LIF.ImI			= ImI;		%I-cells
sessionSummary.params.LIF.gI			= gI;
sessionSummary.params.LIF.cI			= cI;
%
sessionSummary.params.behav.rangeA		= rangeA;
sessionSummary.params.behav.rangeB		= rangeB;
%
offerList = [(1:ntrials)' offA offB];
sessionSummary.behavData.offerList		= offerList;
%
sessionSummary.trajectory.rOV1_traj		= rOV1_traj;
sessionSummary.trajectory.rOV2_traj		= rOV2_traj;
sessionSummary.trajectory.r1_traj		= r1_traj;
sessionSummary.trajectory.r2_traj		= r2_traj;
sessionSummary.trajectory.r3_traj		= r3_traj;
sessionSummary.trajectory.rI_traj		= rI_traj;
sessionSummary.trajectory.s1_traj		= s1_traj;
sessionSummary.trajectory.s2_traj		= s2_traj;
sessionSummary.trajectory.s3_traj		= s3_traj;
sessionSummary.trajectory.sampa1_traj	= sampa1_traj;
sessionSummary.trajectory.sampa2_traj	= sampa2_traj;
sessionSummary.trajectory.sampa3_traj	= sampa3_traj;
sessionSummary.trajectory.sgaba_traj	= sgaba_traj;

%do all the preliminary analyses so we can drop the full trajectories
sessionSummary = get_tuning(sessionSummary);

sessionSummary = rmfield(sessionSummary,'trajectory');
% eval(['save simulations_results/sessionSumm_',filesuffix,' sessionSummary'])
eval(['save sessionSumm_',filesuffix,' sessionSummary'])


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


