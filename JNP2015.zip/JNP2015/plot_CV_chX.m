function [] = plot_CV_chX(filesuffix)
%
% analysis of overshooting in CV cells
%

%#ok<*NODEF>
%#ok<*NASGU>

%clear all

%
% eval(['load simulations_results/sessionSumm_',filesuffix])
eval(['load sessionSumm_',filesuffix])

figure; set(gcf,'position',[650 700 1080 430],'PaperPositionMode','auto'), hold on

%lims for profile plots
xlim_profiles = [-500 1000];
fs = 9; lw = 2;
lw = 1.5;
clrs = [
	0 0 .75
	.6 .6 1];

binTimes	= sessionSummary.CV_traj_chX.chA.binTimes;

%plot results for one particular choice 
subplot(1,2,1), hold on
nn = 8;
CV_traj_chX_easy	= sessionSummary.CV_traj_chX.chA.easy(nn,:);
CV_traj_chX_split	= sessionSummary.CV_traj_chX.chA.split(nn,:);
plot(binTimes, CV_traj_chX_easy,	'-', 'color',clrs(1,:), 'linewidth',lw)
plot(binTimes, CV_traj_chX_split,	'-', 'color',clrs(2,:), 'linewidth',lw)
legend({'easy','split'})
set(gca,'xlim',xlim_profiles)
title([filesuffix,', ',num2str(nn),'A chosen'])


%plot average
subplot(1,2,2), hold on
CV_traj_chX_easy	= [sessionSummary.CV_traj_chX.chA.easy;		sessionSummary.CV_traj_chX.chB.easy];
CV_traj_chX_split	= [sessionSummary.CV_traj_chX.chA.split;	sessionSummary.CV_traj_chX.chB.split];
plot(binTimes, mean(CV_traj_chX_easy),	'-', 'color',clrs(1,:), 'linewidth',lw)
plot(binTimes, mean(CV_traj_chX_split),	'-', 'color',clrs(2,:), 'linewidth',lw)
legend({'easy','split'})
set(gca,'xlim',xlim_profiles)
title(filesuffix)

