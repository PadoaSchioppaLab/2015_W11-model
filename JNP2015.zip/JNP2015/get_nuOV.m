function nuOV = get_nuOV(T_total,T_stimon,dt,rankE)
%
%
%


%

%parameters for 141007

tt = 1:T_total;
a = T_stimon + 175/dt;
b = 30/dt;
c = T_stimon + 400/dt;
d = 100/dt;

fr0 = 0;	%no baseline
Dfr = 8;

% ft = 1./(1+exp(-(tt-a)/b));
ft = 1./(1+exp(-(tt-a)/b)) .* 1./(1+exp((tt-c)/d));							%no tail
% ft = 1./(1+exp(-(tt-a)/b)) .* (1+e*exp((tt-c)/d))./(1+exp((tt-c)/d));		%with tail

nuOV = fr0 + ft/max(ft)*Dfr*rankE;		%excitatory

% nuOVex = fr0 + ft/max(ft)*Dfr*rankE;		%excitatory
% nuOVin = fr0 + ft/max(ft)*Dfr*(1-rankE);	%inhibitory
% nuOV = nuOVex - nuOVin;



% figure, hold on
% colrs = {'r','g','b','k'};
% plot(tt,nuOV,'.','color',colrs{irnk})
% axis([0 T_total/dt 0 Dfr])


return

%parameters for 141107

tt = 1:T_total;
a = T_stimon + 175/dt;
b = 30/dt;
c = T_stimon + 400/dt;
d = 100/dt;

fr0 = 6;	%no baseline
Dfr = 8;

% ft = 1./(1+exp(-(tt-a)/b));
ft = 1./(1+exp(-(tt-a)/b)) .* 1./(1+exp((tt-c)/d));							%no tail
% ft = 1./(1+exp(-(tt-a)/b)) .* (1+e*exp((tt-c)/d))./(1+exp((tt-c)/d));		%with tail

nuOV = fr0 + ft/max(ft)*Dfr*rankE;		%excitatory


return

