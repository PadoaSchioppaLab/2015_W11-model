function [] = plot_hysteresis1(filesuffix)
%
%

%#ok<*NODEF>
%#ok<*NASGU>

%clear all

%
% eval(['load simulations_results/sessionSumm_',filesuffix])
eval(['load sessionSumm_',filesuffix])

offerList = sessionSummary.behavData.offerList;
ntrials = size(offerList,1);
ii_Aprev = find(offerList(:,4))+1;		ii_Aprev = setdiff(ii_Aprev,ntrials+1);
ii_Bprev = find(~offerList(:,4))+1;		ii_Bprev = setdiff(ii_Bprev,ntrials+1);

% figure; set(gcf,'position',[625 375 675 600],'PaperPositionMode','auto')
figure; set(gcf,'position',[570 580 600 545],'PaperPositionMode','auto')

for iprev = 1:2
	clear table01;
	
	if		iprev==1, offLst = offerList(ii_Aprev,:);
	elseif	iprev==2, offLst = offerList(ii_Bprev,:);
	end
	
	offA = offLst(:,2);
	offB = offLst(:,3);
	Bch = ~offLst(:,4);
	
	%compute table01
	offtypes		= unique([offA offB],'rows');
	eps = 0.001;		%sort offtypes
	aux = offtypes + eps;
	[~, jnd] = sort(aux(:,2)./aux(:,1));
	offtypes = offtypes(jnd,:);
	%
	nofftypes		= size(offtypes,1);
	ntrials_offtype = nan(nofftypes,1);
	perc_Bch		= nan(nofftypes,1);
	for i = 1:nofftypes
		ind = ismember([offA offB],offtypes(i,:),'rows');
		ntrials_offtype(i) = sum(ind);
		perc_Bch(i) = sum(ind&Bch)/sum(ind);
	end
	if ~isequal(sum(ntrials_offtype),size(offA,1)), dummy, end
	table01 = [offtypes, perc_Bch, ntrials_offtype];
	
	% Fit: 'untitled fit 1'.
	offA = table01(:,1);
	offB = table01(:,2);
	Bch = table01(:,3);
	[xData, yData, zData] = prepareSurfaceData(offB, offA, Bch);
	
	% Set up fittype and options.
	ft = fittype( 'exp(a+b*x+c*y)/(1+exp(a+b*x+c*y))', 'independent', {'x', 'y'}, 'dependent', 'z' );
% 	ft = fittype( 'exp(a+b*x+c*y+d*x^2+e*y^2+f*x*y)/(1+exp(a+b*x+c*y+d*x^2+e*y^2+f*x*y))', 'independent', {'x', 'y'}, 'dependent', 'z' );
	nn = 3;
	opts = fitoptions(ft);
	opts.Display = 'Off';
	opts.Lower = -Inf(1,nn);
	opts.StartPoint = zeros(1,nn);
	opts.Upper = Inf(1,nn);
	
	% Fit model to data.
	[fitresult, ~] = fit([xData, yData], zData, ft, opts);

	% Plot fit with data.
	hp = plot(fitresult, [xData, yData], zData);
	if		iprev==1, set(hp(2),'marker','s','markerfacecolor',[1 0 0],'markersize',4)
	elseif	iprev==2, set(hp(2),'marker','o','markerfacecolor',[0 0 1],'markersize',4)
	end
		
	hold on
end

%some cosemtics
set(gca,'xtick',0:5:max(offB))
set(gca,'ytick',0:5:max(offA))
set(gca,'ztick',0:.25:1,'zticklabel',{'0','25','50','75','100',})

% Label axes
title(filesuffix)
xlabel('offer B');
ylabel('offer A');
zlabel('%B choice');
grid on

a = nan(1,4);
a(1:2) = get(gca,'xlim');
a(3:4) = get(gca,'ylim');
axis(a);

% set(gca,'view',[-41 13])
set(gca,'view',[-33 23])

