function [] = plot_sessionSummary_bycell(filesuffix)
%
%

%#ok<*NODEF>
%#ok<*NASGU>

% pop_toplot = 'OVB'; %OVA
% pop_toplot = 'CJB';	%CJA
% pop_toplot = 'CV';

%
% eval(['load simulations_results/sessionSumm_',filesuffix])
eval(['load sessionSumm_',filesuffix])

Tstimon_ms	= sessionSummary.params.simul.Tstimon_ms;
Tstimdur_ms	= sessionSummary.params.simul.Tstimdur_ms; %#ok<*NASGU>
Ttotal_ms	= sessionSummary.params.simul.Ttotal_ms;
binsize_ms	= sessionSummary.params.simul.binsize_ms;

rangeA		= sessionSummary.params.behav.rangeA;
rangeB		= sessionSummary.params.behav.rangeB;

offA		= sessionSummary.behavData.offerList(:,2);
offB		= sessionSummary.behavData.offerList(:,3);
table01		= sessionSummary.behavData.table01;
relvalue	= sessionSummary.behavData.relvalue;
width		= sessionSummary.behavData.width;

tuning		= sessionSummary.tuning;

traj_quant	= sessionSummary.traj_quant;
rOV1_quant	= traj_quant.rOV1;
rOV2_quant	= traj_quant.rOV2;
r1_quant	= traj_quant.r1;
r2_quant	= traj_quant.r2;
rI_quant	= traj_quant.rI;
if isfield(traj_quant,'r3')
	r3_quant	= traj_quant.r3;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% plot session results %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

atleast_nntrials = 2;

% if exist('r3_quant','var'),	population_toplot = {'OVB','CJB','CV','NS'};
% else						population_toplot = {'OVB','CJB','CV'};
% end
% population_toplot = {'NS'};
population_toplot = {'OVB','CJB','CV'};

for pops = population_toplot
	pop_toplot = pops{1};
	
	%
	% hf = figure; set(gcf,'position',[325 700 1500 400],'PaperPositionMode','auto')
	if		isequal(pop_toplot(1:2),'OV'),	hf = figure; set(gcf,'position',[325 800 1185 310],'PaperPositionMode','auto')
	elseif	isequal(pop_toplot(1:2),'CJ'),	hf = figure; set(gcf,'position',[325 420 1185 310],'PaperPositionMode','auto')
	elseif	isequal(pop_toplot(1:2),'CV'),	hf = figure; set(gcf,'position',[325  40 1185 310],'PaperPositionMode','auto')
	elseif	isequal(pop_toplot(1:2),'NS'),	hf = figure; set(gcf,'position',[325  40 1185 310],'PaperPositionMode','auto')
	end
	
	%lims for profile plots
	xlim_profiles = [-500 1000];
	fs = 9; lw = 2;
	
	%offer value
	if isequal(pop_toplot(1:2),'OV')
		X = pop_toplot(3);
		if		isequal(X,'A'),	Xnum = num2str(1);
		elseif	isequal(X,'B'),	Xnum = num2str(2);
		end
		eval(['rOVX_quant = rOV',Xnum,'_quant;'])
		
		%plot offval X, profile
		axes('position',[0.05 0.15 0.18 0.7],'fontsize',fs); hold on
		clrs = [1;.7;.4;.1]*[1 .4 .4];
		nquant = size(rOVX_quant,2) - 1;
		binTimes = rOVX_quant(:,1);
		for iquant = 1:nquant
			plot(binTimes, rOVX_quant(:,iquant+1),'-','linewidth',lw, 'color',clrs(iquant,:))
		end %for iquant
		ylim = get(gca,'ylim'); plot([0 0],ylim,'k:')
		set(gca,'xlim',xlim_profiles)
		title(['offer value ',X])
		
		%get neuract
		eval(['neuract = tuning.rOV',Xnum,'.bytrialtype;'])
		ii = neuract(:,end)>=atleast_nntrials;	%impose at least_nntrials
		neuract = neuract(ii,:);
		iiA = neuract(:,3)==1;		%Achosen
		iiB = neuract(:,3)==-1;		%Bchosen
		
		%plot offval X, tuning in full 3D format
		axes('position',[0.30 0.1 0.20 0.75],'fontsize',fs); hold on
		OffA = neuract(:,1);
		OffB = neuract(:,2);
		Fr = neuract(:,4);
		plot3(OffB(iiA),OffA(iiA),Fr(iiA),'rd')
		plot3(OffB(iiB),OffA(iiB),Fr(iiB),'go')
		xlabel('offer B'); ylabel('offer A'); zlabel('Fr');
		grid on, view(-33, 8);
		
		%plot offval X, tuning in experimental format
		ha(1) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		ha(2) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		if		isequal(X,'A'),	tuningplot_W11_downsample(tuning, 'rOV1', ha);
		elseif	isequal(X,'B'),	tuningplot_W11_downsample(tuning, 'rOV2', ha);
		end
		title(['offer value ',X])
		
		%plot offval X, fr against encoded variable, bytrialtype
		axes('position',[0.80 0.15 0.18 0.7],'fontsize',fs); hold on
		title(['offer value ',X])
		if		isequal(X,'A'),
			plot(neuract(iiA,1),neuract(iiA,4),'rd');
			plot(neuract(iiB,1),neuract(iiB,4),'go');
			xmax = 5*ceil(max(neuract(:,1))/5);
		elseif	isequal(X,'B'),
			plot(neuract(iiA,2),neuract(iiA,4),'rd');
			plot(neuract(iiB,2),neuract(iiB,4),'go');
			xmax = 5*ceil(max(neuract(:,2))/5);
		end
		set(gca,'xlim',[0 xmax])
		%legend({'A chosen','B chosen'},2)
		xlabel(['offer value ',X])
	end
	
	%chosen juice
	if isequal(pop_toplot(1:2),'CJ')
		X = pop_toplot(3);
		if		isequal(X,'A'),	Xnum = num2str(1);
		elseif	isequal(X,'B'),	Xnum = num2str(2);
		end
		eval(['rX_quant = r',Xnum,'_quant;'])
		
		%plot chjuice, profile
		axes('position',[0.05 0.15 0.18 0.7],'fontsize',fs); hold on
		binTimes = rX_quant(:,1);
		plot(binTimes, rX_quant(:,2),'r-','linewidth',lw)
		plot(binTimes, rX_quant(:,3),'g-','linewidth',lw)
		ylim = get(gca,'ylim'); plot([0 0],ylim,'k:')
		set(gca,'xlim',xlim_profiles)
		title(['chosen juice ',X])
		
		%get neuract
		eval(['neuract = tuning.r',Xnum,'.bytrialtype;'])
		ii = neuract(:,end)>=atleast_nntrials;	%impose at least_nntrials
		neuract = neuract(ii,:);
		iiA = neuract(:,3)==1;
		iiB = neuract(:,3)==-1;
		
		%plot chjuice X, tuning in full 3D format
		axes('position',[0.30 0.1 0.20 0.75],'fontsize',fs); hold on
		OffA = neuract(:,1);
		OffB = neuract(:,2);
		Fr = neuract(:,4);
		plot3(OffB(iiA),OffA(iiA),Fr(iiA),'rd')
		plot3(OffB(iiB),OffA(iiB),Fr(iiB),'go')
		xlabel('offer B'); ylabel('offer A'); zlabel('Fr');
		grid on, view(-33, 8);
		
		%plot chjuice X, tuning in experimental format
		ha(1) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		ha(2) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		if		isequal(X,'A'),	tuningplot_W11_downsample(tuning, 'r1', ha);
		elseif	isequal(X,'B'),	tuningplot_W11_downsample(tuning, 'r2', ha);
		end
		title(['chosen juice ',X])
		
		%plot chjuice X, fr against encoded variable, bytrialtype
		axes('position',[0.80 0.15 0.18 0.7],'fontsize',fs); hold on
		title(['chosen juice ',X])
		plot(zeros(sum(iiA),1),neuract(iiA,4),'rd');
		plot( ones(sum(iiB),1),neuract(iiB,4),'go');
		set(gca,'xlim',[-.2 1.2],'xtick',[0 1],'xticklabel',{'A chosen','B chosen'})
	end
	
	
	%chosen value
	if isequal(pop_toplot,'CV')
		
		%plot chvalue, profile
		axes('position',[0.05 0.15 0.18 0.7],'fontsize',fs); hold on
		clrs = [1;.7;.4;.1]*[1 .5 0];
		nquant = size(rI_quant,2) - 1;
		binTimes = rI_quant(:,1);
		for iquant = 1:nquant
			plot(binTimes, rI_quant(:,iquant+1),'-','linewidth',lw, 'color',clrs(iquant,:))
		end %for iquant
		ylim = get(gca,'ylim'); plot([0 0],ylim,'k:')
		set(gca,'xlim',xlim_profiles)
		title('chosen value')
		
		%get neuract
		neuract = tuning.rI.bytrialtype;
		ii = neuract(:,end)>=atleast_nntrials;	%impose at least_nntrials
		neuract = neuract(ii,:);
		iiA = neuract(:,3)==1;
		iiB = neuract(:,3)==-1;
		
		%plot chvalue, tuning in full 3D format
% 		axes('position',[0.30 0.15 0.18 0.7],'fontsize',fs); hold on
		axes('position',[0.30 0.1 0.20 0.75],'fontsize',fs); hold on
		OffA = neuract(:,1);
		OffB = neuract(:,2);
		Fr = neuract(:,4);
		plot3(OffB(iiA),OffA(iiA),Fr(iiA),'rd')
		plot3(OffB(iiB),OffA(iiB),Fr(iiB),'go')
		xlabel('offer B'); ylabel('offer A'); zlabel('Fr');
		grid on, view(-18, 8);
		
		%plot chvalue, tuning in experimental format
		ha(1) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		ha(2) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		tuningplot_W11_downsample(tuning, 'rI', ha);
		title('chosen value')
		
		%plot chjuice X, fr against encoded variable, bytrialtype
		axes('position',[0.80 0.15 0.18 0.7],'fontsize',fs); hold on
		xxA =  neuract(iiA,1)*relvalue;
		xxB =  neuract(iiB,2);
		plot(xxA,neuract(iiA,4),'rd');
		plot(xxB,neuract(iiB,4),'go');
		xmax = 5*ceil(max([xxA;xxB]/5));
		set(gca,'xlim',[0 xmax])
		%legend({'A chosen','B chosen'},2)
		xlabel('chosen value (uB)')
		title('firing rate of rI')
	end
	
	
	%non selective
	if isequal(pop_toplot,'NS')
		
		%plot chvalue, profile
		axes('position',[0.05 0.15 0.18 0.7],'fontsize',fs); hold on
		clrs = [1;.7;.4;.1]*[1 .5 0];
		nquant = size(r3_quant,2) - 1;
		binTimes = r3_quant(:,1);
		for iquant = 1:nquant
			plot(binTimes, r3_quant(:,iquant+1),'-','linewidth',lw, 'color',clrs(iquant,:))
		end %for iquant
		ylim = get(gca,'ylim');
		ylim(1) = floor(ylim(1));
		ylim(2) = round(ylim(2));
		plot([0 0],ylim,'k:')
		set(gca,'xlim',xlim_profiles,'ylim',ylim)
		title('non selective')
		
		%get neuract
		neuract = tuning.r3.bytrialtype;
		ii = neuract(:,end)>=atleast_nntrials;	%impose at least_nntrials
		neuract = neuract(ii,:);
		iiA = neuract(:,3)==1;
		iiB = neuract(:,3)==-1;
		
		%plot chvalue, tuning in full 3D format
% 		axes('position',[0.30 0.15 0.18 0.7],'fontsize',fs); hold on
		axes('position',[0.30 0.1 0.20 0.75],'fontsize',fs); hold on
		OffA = neuract(:,1);
		OffB = neuract(:,2);
		Fr = neuract(:,4);
		plot3(OffB(iiA),OffA(iiA),Fr(iiA),'rd')
		plot3(OffB(iiB),OffA(iiB),Fr(iiB),'go')
		xlabel('offer B'); ylabel('offer A'); zlabel('Fr');
		grid on, view(-18, 8);
		zlim = get(gca,'zlim'); 
		zlim(1) = floor(zlim(1)); zlim(2) = ceil(2*zlim(2))/2; set(gca,'zlim',zlim)
		
		%plot chvalue, tuning in experimental format
		ha(1) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		ha(2) = axes('position',[0.55 0.15 0.18 0.7],'fontsize',fs); hold on
		tuningplot_W11_downsample(tuning, 'r3', ha);
		set(ha(2),'ylim',zlim)
		title('non selective')
		
		%plot chjuice X, fr against encoded variable, bytrialtype
		axes('position',[0.80 0.15 0.18 0.7],'fontsize',fs); hold on
		xxA =  neuract(iiA,1)*relvalue;
		xxB =  neuract(iiB,2);
		plot(xxA,neuract(iiA,4),'rd');
		plot(xxB,neuract(iiB,4),'go');
% 		xmax = 5*ceil(max([xxA;xxB]/5));
% 		set(gca,'xlim',[0 xmax])
		%legend({'A chosen','B chosen'},2)
		xlabel('chosen value (uB)')
		title('firing rate of r3')
	end
	
end